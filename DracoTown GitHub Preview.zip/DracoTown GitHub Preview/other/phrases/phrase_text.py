def ph1():
    return """This is Dragon Town! A large and vast Game coded with Python.
How to Play:
1. Enter the Commands that are given
2. Play accordingly
3. Have Fun
NOTICE: ALL PROGRESS MADE WILL NOT BE SAVED
BECAUSE DracoTown DOES NOT HAVE A SETUP 
DATABASE!!!
"""

