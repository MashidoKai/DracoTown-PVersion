def sword1():
    return "$50"

def scrambled_eggs():
    return "$10"