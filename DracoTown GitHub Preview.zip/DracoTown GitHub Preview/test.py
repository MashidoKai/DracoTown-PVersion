import time
from functions.clear import clear
from assets import item_values

invi = [ "sword", "cup", "eggs" ]
money = [ "1000" ]
health = [ "100" ]
level = [ "1" ]
next_level = [ "0.00" ]

def play():
    to_do = input("Dragon Town Hub:\n\nWhat would you like to do?\n\n1 = Check out Inventory/Player Info\n2 = Find a Quest\n3 = Check out Stores\n\nWhat do you say: ")
    clear()
# Userinfo/Inventory ------------------------------------------------------------------------------------------------------------------------------------------------------
    if to_do.lower() ==  "1":
        def piiv():
            print( "Player Info:\n\n" + "Level: " + str(level[0]) + "\n" + "Health: " + health[0] + "\n" + "Balance: $" + str(money[0]) + "\n" + "\nHow much till next level?: " + str(next_level[0]) + "\n" )
            print( "Inventory:\n\n" + str(invi))
            print("\nCommands:\n1 = Value\n2 = Eat\n3 = Exit\n")
            cmd = input("What do you say: ")
# Eat Command ------------------------------------------------------------------------------------------------------------------------------------------------------
            if cmd.lower() == "2":
                eat_response = input( "What would you like to eat?: " ) # removes an item from the set
                if eat_response.lower() == "eggs":
                    clear()
                    invi.remove("eggs")
                    print( "Yum! You ate eggs" )
                    time.sleep(4)
                    clear()
                    play()
# Value Command ------------------------------------------------------------------------------------------------------------------------------------------------------
            elif cmd.lower() == "1":
                value_response = input( "What would you like to see the value of?: " )
                if value_response.lower() == "sword":
                    clear()
                    sd1 = item_values.sword1()
                    print( "The value of your " + value_response + " is currently " + sd1 ) # If you have eggs it outputs the value
                    time.sleep(4)
                    clear()
                    play()
                elif value_response.lower() == "eggs":
                    if "eggs" in invi:
                        clear()
                        sd1 = item_values.scrambled_eggs()
                        print( "The value of your " + value_response + " is currently " + sd1 ) # Checks to see if you have eggs
                        time.sleep(4)
                        clear()
                        play()
                    elif "eggs" not in invi:
                        clear()
                        print( "You do not have eggs in your invintory" )
                        time.sleep(4)
                        clear()
                        play()
                elif value_response.lower() == "cup":
                    clear()
                    print( "Its just a cup" )
                    time.sleep(3)
                    clear()
                    play()
                elif value_response.lower() == "":
                    clear()
                    print( "You must type an item" )
                    piiv()
            elif cmd.lower() == "":
                clear()
                print( "You must type an item" )
                piiv()


# Exit Inv/UserInfo ------------------------------------------------------------------------------------------------------------------------------------------------------
            elif cmd.lower() == "3":
                clear()
                play()
# Starts selection 1 ------------------------------------------------------------------------------------------------------------------------------------------------------
        piiv()
# Quests ------------------------------------------------------------------------------------------------------------------------------------------------------
    elif to_do.lower() == "2":
        print("Quests are not available yet")
# Shops ------------------------------------------------------------------------------------------------------------------------------------------------------
    elif to_do.lower() == "3":
        clear()
        def sup():
            print( "Welcome to the Monstad shops\n" )
            print( "Balance: " + str(money[0]) )
            print( "\nStores:\n1 = Supermarket    2 = Blacksmith\n3 = Brewer         4 = CheapStore\n\nType 'Exit' to Exit this Page\n")
            x = input( "What do you say?: " )
# Supermarket ------------------------------------------------------------------------------------------------------------------------------------------------------
            if x.lower() == "1":
                clear()
                print( "Welcome to the Supermarket" )
                print( "Items on Sale:\n\n1 = Apple - $5\n2 = Cooked Potato - $7\n3 = Apple Pie - $10\n4 = Bottle - $3\n5 = Fish - $6\n6 = Rotten Boot - $2\n\nType 'Exit' to Exit..")
                p = input( "What do you say?: ")
# Item1 ------------------------------------------------------------------------------------------------------------------------------------------------------
                if p.lower() == "1":
                    if int(money[0]) >= 5:
                        sum = int(money[0]) - 5
                        money.append(sum)
                        money.remove(money[0])
                        invi.append("apple")
                        clear()
                        print( "You Purchaced an apple.")
                        sup()
                    elif int(money[0]) != 5:
                        clear()
                        print( "You dont have enough money to buy this item..." )
                        sup()
# Item2 ------------------------------------------------------------------------------------------------------------------------------------------------------
                elif p.lower() == "2":
                    if int(money[0]) >= 7:
                        sum = int(money[0]) - 7
                        money.append(sum)
                        money.remove(money[0])
                        invi.append("cooked potato")
                        clear()
                        print( "You Purchaced a cooked potato.")
                        sup()
                    elif int(money[0]) != 7:
                        clear()
                        print( "You dont have enough money to buy this item..." )
                        sup()
# Item3 ------------------------------------------------------------------------------------------------------------------------------------------------------
                elif p.lower() == "3":
                    if int(money[0]) >= 10:
                        sum = int(money[0]) - 10
                        money.append(sum)
                        money.remove(money[0])
                        invi.append("apple pie")
                        clear()
                        print( "You Purchaced an apple pie.")
                        sup()
                    elif str(money[0]) != 5:
                        clear()
                        print( "You dont have enough money to buy this item..." )
                        sup()
# Item4 ------------------------------------------------------------------------------------------------------------------------------------------------------
                elif p.lower() == "4":
                    if int(money[0]) >= 3:
                        sum = int(money[0]) - 3
                        money.append(sum)
                        money.remove(money[0])
                        invi.append("bottle")
                        clear()
                        print( "You Purchaced a bottle.")
                        sup()
                    elif int(money[0]) != 3:
                        clear()
                        print( "You dont have enough money to buy this item..." )
                        sup()
# Item5 ------------------------------------------------------------------------------------------------------------------------------------------------------
                elif p.lower() == "5":
                    if int(money[0]) >= 6:
                        sum = int(money[0]) - 6
                        money.append(sum)
                        money.remove(money[0])
                        invi.append("fish")
                        clear()
                        print( "You Purchaced a fish.")
                        sup()
                    elif int(money[0]) != 6:
                        clear()
                        print( "You dont have enough money to buy this item..." )
                        sup()
# Item6 ------------------------------------------------------------------------------------------------------------------------------------------------------                        
                elif p.lower() == "6":
                    if int(money[0]) >= 2:
                        sum = int(money[0]) - 2
                        money.append(sum)
                        money.remove(money[0])
                        invi.append("rotten boot")
                        clear()
                        print( "You Purchaced a rotten boot.")
                        sup()
                    elif int(money[0]) != 2:
                        clear()
                        print( "You dont have enough money to buy this item..." )
                        sup()
# Blacksmith ------------------------------------------------------------------------------------------------------------------------------------------------------
            elif x.lower() == "2":
                clear()
                print( "Welcome to the Blacksmith" )
# Brewer ------------------------------------------------------------------------------------------------------------------------------------------------------                
            elif x.lower() == "3":
                clear()
                print( "Welcome to the Brewer" )
# Cheapstore ------------------------------------------------------------------------------------------------------------------------------------------------------                
            elif x.lower() == "4":
                clear()
                print( "Welcome to the CheapStore" )
# Others ------------------------------------------------------------------------------------------------------------------------------------------------------
            elif x.lower() == "exit":
                clear()
                play()
            elif x.lower() == "":
                clear()
                print( "You Must input a number from the list below or type 'Exit'...\n" )
                sup()
            elif x.lower() != "1":
                clear()
                print( x + " is not a number...\n" )
                sup()
            elif x.lower() != "2":
                clear()
                print( x + " is not a number...\n" )
                sup()
            elif x.lower() != "3":
                clear()
                print( x + " is not a number...\n" )
                sup()
            elif x.lower() != "4":
                clear()
                print( x + " is not a number...\n" )
                sup()
        sup()

    elif to_do.lower() == "":
        clear()
        print( "You must put a command\n" )
        play()

    elif to_do.lower() != "1":
        clear()
        print( to_do + " is not a command\n" )
        play()

    elif to_do.lower() != "2":
        clear()
        print( to_do + " is not a command\n" )
        play()

    elif to_do.lower() != "3":
        clear()
        print( to_do + " is not a command\n" )
        play()


play()