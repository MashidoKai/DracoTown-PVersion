bal = [ "10" ]

def b():
    s = input("y or n")
    if s == "y":
        if int(bal[0]) > 0:
            sum = int(bal[0]) - 5
            bal.append(sum)
            bal.remove(bal[0])
            print("bal is " + str(sum))
            b()
        else:
            print("You dont have enough money")
            b()
    elif s == "n":
        print(bal)
        b()

b()
