import sys
import time
from other.phrases import phrase_text
from functions.clear import clear
from assets import item_values

invi = [ "sword", "cup", 'eggs' ]
money = [ "1000" ]

def username():
    welcome_text = "Welcome to the Dragon Town!" 

    for char in welcome_text:
        print(char, end='')
        sys.stdout.flush()
        time.sleep(0.06)

    print()
    user_name = input( "Enter a Username: " )
    if user_name == "":
        clear()
        print( "Please Enter a valid Username" )
        username()
    elif user_name != "":
        pass

    clear()

    for char in "Welcome " + user_name + "!":
        print(char, end='')
        sys.stdout.flush()
        time.sleep(0.06)
    print()
    for char in phrase_text.ph1():
        print(char, end='')
        sys.stdout.flush()
        time.sleep(0.06)

    def read():
        ready = input( "Type 'Ready' when you are ready to continue: " )

        if ready.lower() == "ready":
            pass
        elif ready.lower != "ready":
            print("The program does not know what to do. Quitting game...")
    
    read()

    def play():
        clear()
        to_do = input("Dragon Town Hub:\n\nWhat would you like to do?\n\n1 = Check out Inventory/Player Info\n2 = Find a Quest\n3 = Check out Stores\n\nWhat do you say: ")
        clear()

        if to_do.lower() ==  "1":
            print( "Player Info:\n" + "Username: " + user_name + "\n" + "Balance: " + money[0] + "\n" )
            print( "Inventory\n" + str(invi))
            print("\nCmds:\n1 = Value\n2 = Eat\n3 = Exit\n")
            cmd = input("What do you say: ")
            if cmd.lower() == "2":
                eat_response = input( "What would you like to eat?: " ) # removes an item from the set
                if eat_response.lower() == "eggs":
                    clear()
                    invi.remove("eggs")
                    print( "Yum! You ate eggs" )
                    time.sleep(4)
                    clear()
                    play()
            elif cmd.lower() == "1":
                value_response = input( "What would you like to see the value of?: " )
                if value_response.lower() == "sword":
                    clear()
                    sd1 = item_values.sword1()
                    print( "The value of your " + value_response + " is currently " + sd1 ) # If you have eggs it outputs the value
                    time.sleep(4)
                    clear()
                    play()
                elif value_response.lower() == "eggs":
                    if "eggs" in invi:
                        clear()
                        sd1 = item_values.scrambled_eggs()
                        print( "The value of your " + value_response + " is currently " + sd1 ) # Checks to see if you have eggs
                        time.sleep(4)
                        clear()
                        play()
                    elif "eggs" not in invi:
                        clear()
                        print( "You do not have eggs in your invintory" )
                        time.sleep(4)
                        clear()
                        play()
                elif value_response.lower() == "cup":
                    clear()
                    print( "Its just a cup" )
                    time.sleep(3)
                    clear()
                    play()
            elif cmd.lower() == "3":
                clear()
                play()
        elif to_do.lower() == "2":
            print("Quests are not available yet")
        elif to_do.lower() == "3":
            clear()
            def sup():
                print( "Welcome to the Monstad shops\n" )
                print( "Balance: " + str(money[0]) )
                print( "\nStores:\n1 = Supermarket    2 = Blacksmith\n3 = Brewer         4 = CheapStore\n\nType 'Exit' to Exit this Page\n")
                x = input( "What do you say?: " )
                if x.lower() == "1":
                    clear()
                    print( "Welcome to the Supermarket")
                elif x.lower() == "2":
                    clear()
                    print( "Welcome to the Blacksmith")
                elif x.lower() == "3":
                    clear()
                    print( "Welcome to the Brewer")
                elif x.lower() == "4":
                    clear()
                    print( "Welcome to the CheapStore" )
                elif x.lower() == "exit":
                    clear()
                    play()
                elif x.lower() == "":
                    clear()
                    print( "You Must input a number from the list below or type 'Exit'...\n" )
                    sup()
                elif x.lower() != "1":
                    clear()
                    print( x + " is not a number...\n" )
                    sup()
                elif x.lower() != "2":
                    clear()
                    print( x + " is not a number...\n" )
                    sup()
                elif x.lower() != "3":
                    clear()
                    print( x + " is not a number...\n" )
                    sup()
                elif x.lower() != "4":
                    clear()
                    print( x + " is not a number...\n" )
                    sup()
            sup()
        elif to_do.lower() == "":
            clear()
            print( "You must put a command\n" )
            play()
        elif to_do.lower() != "1":
            clear()
            print( to_do + " is not a command\n" )
            play()
        elif to_do.lower() != "2":
            clear()
            print( to_do + " is not a command\n" )
            play()
        elif to_do.lower() != "3":
            clear()
            print( to_do + " is not a command\n" )
            play()

    play()


username()