PY PROJECT
VERS_0.00.0
VERS_0.00.1
VERS_0.00.6

Do not Delete any file in Py Project.